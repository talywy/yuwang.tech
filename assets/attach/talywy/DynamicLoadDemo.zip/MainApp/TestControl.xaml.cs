﻿using System.Windows;
using System.Windows.Controls;

namespace MainApp
{
    public partial class TestControl : UserControl
    {
        public static readonly DependencyProperty TextProperty = DependencyProperty.Register(
        "Text", typeof(string), typeof(TestControl),
        new PropertyMetadata("Test Control"));

        /// <summary>
        /// 文本
        /// </summary>
        public string Text
        {
            get { return (string)GetValue(TextProperty); }
            set { SetValue(TextProperty, value); }
        }

        public TestControl()
        {
            InitializeComponent();
            this.DataContext = this;

            // 不推荐这种方法
            //var style = Application.Current.Resources["TestStyle"] as Style;
            //if (style != null)
            //{
            //    TxtTest.Style = style;
            //}
        }
    }
}
