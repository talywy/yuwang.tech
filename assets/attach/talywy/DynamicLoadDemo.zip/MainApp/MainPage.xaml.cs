﻿using System;
using System.Net;
using System.Reflection;
using System.Windows;
using System.Windows.Browser;
using System.Windows.Controls;

namespace MainApp
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 加载员工列表按钮点击事件
        /// </summary>
        private void BtnLoadEmployeeListClick(object sender, RoutedEventArgs e)
        {
            LayoutRoot.Children.Remove(BtnLoadEmployeeList);
            LoadXapProgressPanel.Visibility = Visibility.Visible;

            // 下载xap包
            var xapClient = new WebClient();
            xapClient.OpenReadCompleted += new OpenReadCompletedEventHandler(ManageXapOpenReadCompleted);
            xapClient.DownloadProgressChanged += new DownloadProgressChangedEventHandler(ManageXapDownloadProgressChanged);
            var xapUri = new Uri(HtmlPage.Document.DocumentUri, "ClientBin/EmployeeDataGrid.xap");
            xapClient.OpenReadAsync(xapUri);
        }

        /// <summary>
        /// Xap包下载完成
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ManageXapOpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
        {
            if (e.Error == null)
            {
                // 利用反射创建页面
                Assembly assembly = XapHelper.LoadAssemblyFromXap(e.Result);
                var employeeDataGrid = assembly.CreateInstance("EmployeeDataGrid.MainPage") as UserControl;

                // 将列表页面加载到主页面中
                Grid.SetRow(employeeDataGrid, 1);
                LayoutRoot.Children.Add(employeeDataGrid);

                LayoutRoot.Children.Remove(LoadXapProgressPanel);
            }
            else
            {
                MessageBox.Show(e.Error.Message);
            }
        }

        /// <summary>
        /// 下载进度汇报
        /// </summary>
        private void ManageXapDownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
        {
            XapLoadText.Text = e.ProgressPercentage.ToString();
            XapLoadProgress.Value = e.ProgressPercentage;
        }
    }
}
