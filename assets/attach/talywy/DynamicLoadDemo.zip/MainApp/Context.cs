﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using Model;

namespace MainApp
{
    public class Context
    {
        private Context()
        {
            Employees = new ObservableCollection<Employee>
            {
                new Employee{ Name ="张三", Age= 25, Gender= Gender.Male},
                new Employee{ Name ="李四", Age= 28, Gender= Gender.Female},
                new Employee{ Name ="王五", Age= 24, Gender= Gender.Other},
                new Employee{ Name ="赵六", Age= 33, Gender= Gender.Male}
            };
        }

        private static Context _instance;
        public static Context Instance
        {
            get { return _instance ?? (_instance = new Context()); }
        }

        /// <summary>
        /// 
        /// </summary>
        public ObservableCollection<Employee> Employees
        {
            get;
            private set;
        }

        /// <summary>
        /// 模拟数据服务端分页及排序
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortName"></param>
        /// <param name="sordDir"></param>
        /// <returns></returns>
        public IEnumerable<Employee> QueryEmployees(int pageIndex, int pageSize, string sortName, SortDir sordDir)
        {
            return null;
        }
    }
}
