﻿using System.Windows;
using System.Windows.Controls;
using MainApp;
using Model;

namespace EmployeeDataGrid
{
    public partial class AddEmployeeWin : ChildWindow
    {
        private Gender _gender = Gender.Male;

        public AddEmployeeWin()
        {
            InitializeComponent();
        }

        private void OKButtonClick(object sender, RoutedEventArgs e)
        {
            var name = TxtName.Text.Trim();
            if (name.Length == 0)
            {
                MessageBox.Show("姓名不合法");
                return;
            }

            int age;
            if (!int.TryParse(TxtAge.Text, out age) || age < 10 || age > 80)
            {
                MessageBox.Show("年龄不合法");
                return;
            }

            var employee = new Employee
            {
                Name = name,
                Age = age,
                Gender = _gender
            };
            Context.Instance.Employees.Add(employee);
            this.DialogResult = true;
        }

        private void CancelButtonClick(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        private void RdbGenderChecked(object sender, RoutedEventArgs e)
        {
            var gender = ((RadioButton)sender).Content.ToString();
            if (gender == "男")
            {
                _gender = Gender.Male;
            }
            else if (gender == "女")
            {
                _gender = Gender.Female;
            }
            else
            {
                _gender = Gender.Other;
            }
        }
    }
}