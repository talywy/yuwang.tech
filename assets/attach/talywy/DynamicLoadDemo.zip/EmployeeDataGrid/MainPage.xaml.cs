﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using MainApp;

namespace EmployeeDataGrid
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();

            var bind = new Binding("Employees");
            bind.Source = Context.Instance;
            EmployeeDataGrid.SetBinding(DataGrid.ItemsSourceProperty, bind);
        }

        private void BtnAddEmployeeClick(object sender, RoutedEventArgs e)
        {
            new AddEmployeeWin().Show();
        }
    }
}
