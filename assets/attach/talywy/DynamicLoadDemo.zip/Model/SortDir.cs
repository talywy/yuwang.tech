﻿namespace Model
{
    /// <summary>
    /// 排序方向
    /// </summary>
    public enum SortDir
    {
        /// <summary>
        /// 正序
        /// </summary>
        ASC,

        /// <summary>
        /// 逆序
        /// </summary>
        DESC
    }
}
