﻿using System.ComponentModel;

namespace Model
{
    public class Employee : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private string _name;
        private int _age;
        private Gender _gender;

        /// <summary>
        /// 性别
        /// </summary>
        public Gender Gender
        {
            get { return _gender; }
            set
            {
                if (value != _gender)
                {
                    _gender = value;
                    NotifyPropertyChanged("Gender");
                }

            }
        }

        /// <summary>
        /// 年龄
        /// </summary>
        public int Age
        {
            get { return _age; }
            set
            {
                if (value != _age)
                {
                    _age = value;
                    NotifyPropertyChanged("Age");
                }
            }
        }

        /// <summary>
        /// 姓名
        /// </summary>
        public string Name
        {
            get { return _name; }
            set
            {
                if (value != _name)
                {
                    _name = value;
                    NotifyPropertyChanged("Name");
                }
            }
        }

        private void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
