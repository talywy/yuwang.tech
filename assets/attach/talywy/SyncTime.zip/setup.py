'''
Created on Feb 26, 2013

@author: Taly.W.Y
'''
from distutils.core import setup
import py2exe

setup(
    # The first three parameters are not required, if at least a
    # 'version' is given, then a versioninfo resource is built from
    # them and added to the executables.
    version = "0.0.1",
    description = "Synchroniz local system time with beijin time",
    name = "sysctime",

    # targets to build
    # console = ["synctime.py"],
    service=["synctime"]
)