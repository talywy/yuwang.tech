﻿using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace VirtualizingPanelDemo
{
    /// <summary>
    /// Interaction logic for ResourcePager.xaml
    /// </summary>
    public partial class ResourcePager : UserControl
    {
        #region Dependency Property

        public static readonly DependencyProperty TotalItemsCountProperty = DependencyProperty.Register(
            "TotalItemsCount", typeof(int), typeof(ResourcePager), new PropertyMetadata(TotalPageCountConditonChanged));

        public static readonly DependencyProperty PageSizeProperty = DependencyProperty.Register(
            "PageSize", typeof(int), typeof(ResourcePager), new PropertyMetadata(10, TotalPageCountConditonChanged));

        public static readonly DependencyProperty PageIndexProperty = DependencyProperty.Register(
            "PageIndex", typeof(int), typeof(ResourcePager), new PropertyMetadata(PageIndexPropertyChanged));

        public static readonly DependencyProperty TotalPageCountProperty = DependencyProperty.Register(
            "TotalPageCount", typeof(int), typeof(ResourcePager), new PropertyMetadata(CreatePageButtonConditionChanged));

        public static readonly DependencyProperty PageButtonCountProperty = DependencyProperty.Register(
            "PageButtonCount", typeof(int), typeof(ResourcePager), new PropertyMetadata(5, CreatePageButtonConditionChanged));

        private static void TotalPageCountConditonChanged(DependencyObject sender, DependencyPropertyChangedEventArgs e)
        {
            ResourcePager pager = (ResourcePager)sender;

            // 计算页码总数
            int totalPageCount;
            if (pager.PageSize > 0)
            {
                totalPageCount = pager.TotalItemsCount / pager.PageSize;
                if (pager.TotalItemsCount % pager.PageSize > 0)
                {
                    totalPageCount++;
                }
            }
            else
            {
                totalPageCount = 0;
            }
            pager.TotalPageCount = totalPageCount;

            // 计算当前页索引
            if (pager.PageIndex * pager.PageSize > pager.TotalItemsCount)
            {
                pager.PageIndex = 0;
            }

            CommandManager.InvalidateRequerySuggested();
        }

        private static void PageIndexPropertyChanged(DependencyObject sender, DependencyPropertyChangedEventArgs e)
        {
            var pager = (ResourcePager)sender;

            pager.CreatePageButton(pager.TotalPageCount, pager.PageButtonCount, pager.PageIndex);
        }

        private static void CreatePageButtonConditionChanged(DependencyObject sender, DependencyPropertyChangedEventArgs e)
        {
            var pager = (ResourcePager)sender;
            pager.CreatePageButton(pager.TotalPageCount, pager.PageButtonCount, pager.PageIndex);
        }

        #endregion

        #region Command

        public static readonly RoutedCommand ChangePageCmd = new RoutedCommand();
        public static readonly RoutedCommand NextPageCmd = new RoutedCommand();
        public static readonly RoutedCommand PrevPageCmd = new RoutedCommand();
        public static readonly RoutedCommand FirstPageCmd = new RoutedCommand();
        public static readonly RoutedCommand LastPageCmd = new RoutedCommand();

        private void BinndCommand()
        {
            CommandBindings.Add(new CommandBinding(ChangePageCmd, ChangePageCmdExcuted));
            CommandBindings.Add(new CommandBinding(NextPageCmd, NextPageCmdExcuted, CanNextPageCmdExcute));
            CommandBindings.Add(new CommandBinding(PrevPageCmd, PrevPageCmdExcuted, CanPrevPageCmdExcute));
            CommandBindings.Add(new CommandBinding(FirstPageCmd, FirstPageCmdExcuted, CanFirstPageCmdExcute));
            CommandBindings.Add(new CommandBinding(LastPageCmd, LastPageCmdExcuted, CanLastPageCmdExcute));
        }

        private void ChangePageCmdExcuted(object sender, ExecutedRoutedEventArgs e)
        {
            PageIndex = int.Parse(e.Parameter.ToString()) - 1;
        }

        private void NextPageCmdExcuted(object sender, ExecutedRoutedEventArgs e)
        {
            PageIndex++;
        }

        private void CanNextPageCmdExcute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = PageIndex < TotalPageCount - 1;
        }

        private void PrevPageCmdExcuted(object sender, ExecutedRoutedEventArgs e)
        {
            PageIndex--;
        }

        private void CanPrevPageCmdExcute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = PageIndex > 0 && TotalPageCount > 0;
        }

        private void FirstPageCmdExcuted(object sender, ExecutedRoutedEventArgs e)
        {
            PageIndex = 0;
        }

        private void CanFirstPageCmdExcute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = PageIndex > 0 && TotalPageCount > 0;
        }

        private void LastPageCmdExcuted(object sender, ExecutedRoutedEventArgs e)
        {
            PageIndex = TotalPageCount - 1;
        }

        private void CanLastPageCmdExcute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = PageIndex < TotalPageCount - 1;
        }

        #endregion

        #region Property

        /// <summary>
        /// 资源总数
        /// </summary>
        public int TotalItemsCount
        {
            get { return (int)GetValue(TotalItemsCountProperty); }
            set { SetValue(TotalItemsCountProperty, value); }
        }

        /// <summary>
        /// 每页显示资源数
        /// </summary>
        public int PageSize
        {
            get { return (int)GetValue(PageSizeProperty); }
            set { SetValue(PageSizeProperty, value); }
        }

        /// <summary>
        /// 当前页码
        /// </summary>
        public int PageIndex
        {
            get { return (int)GetValue(PageIndexProperty); }
            set { SetValue(PageIndexProperty, value); }
        }

        /// <summary>
        /// 分页按钮显示个数
        /// </summary>
        public int PageButtonCount
        {
            get { return (int)GetValue(PageButtonCountProperty); }
            set { SetValue(PageButtonCountProperty, value); }
        }

        /// <summary>
        /// 分页按钮总个数
        /// </summary>
        public int TotalPageCount
        {
            get { return (int)GetValue(TotalPageCountProperty); }
            private set { SetValue(TotalPageCountProperty, value); }
        }

        #endregion

        #region Construct

        public ResourcePager()
        {
            InitializeComponent();
            BinndCommand();

            if (!DesignerProperties.GetIsInDesignMode(this))
            {
                PageBtnPanel.Children.Clear();
            }
        }

        #endregion

        #region Private Method

        /// <summary>
        /// 创建分页按钮
        /// </summary>
        private void CreatePageButton(int totalPageCount, int pageButtonCount, int pageIndex)
        {
            int realPageButtonCount = Math.Min(totalPageCount, pageButtonCount);

            // 计算起止分页按钮
            int startPageIndex = pageIndex - realPageButtonCount / 2;
            if (startPageIndex < 0)
            {
                startPageIndex = 0;
            }
            if (startPageIndex + realPageButtonCount > totalPageCount)
            {
                startPageIndex = totalPageCount - realPageButtonCount;
            }

            int endPageIndex = startPageIndex + realPageButtonCount;


            // 创建分页按钮
            PageBtnPanel.Children.Clear();
            for (int index = startPageIndex; index < endPageIndex; index++)
            {
                var pageButton = new RadioButton { Content = index + 1 };
                if (index == PageIndex)
                {
                    pageButton.IsChecked = true;
                }
                PageBtnPanel.Children.Add(pageButton);
            }

            CommandManager.InvalidateRequerySuggested();
        }

        #endregion
    }
}
