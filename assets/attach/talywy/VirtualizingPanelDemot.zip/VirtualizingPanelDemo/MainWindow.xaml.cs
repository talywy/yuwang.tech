﻿using System.Collections.ObjectModel;
using System.Windows;

namespace VirtualizingPanelDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnShowSplitPanelWindowClick(object sender, RoutedEventArgs e)
        {
            new SplitPanelWindow().Show();
        }

        private void BtnShowVirtualizingPagerPanelWindowClick(object sender, RoutedEventArgs e)
        {
            new VirtualizingPagerPanelWindow().Show();
        }

        private void BtnShowItemContatinerGeneratorDemoClick(object sender, RoutedEventArgs e)
        {
            new ItemContainerGeneratorDemoWindow().Show();
        }

        private void BtnShowTestWindowClick(object sender, RoutedEventArgs e)
        {
            new TestWindow().Show();
        }
    }
}
