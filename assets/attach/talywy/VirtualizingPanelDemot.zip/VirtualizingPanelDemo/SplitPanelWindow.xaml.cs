﻿using System;
using System.Diagnostics;
using System.Threading;
using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;

namespace VirtualizingPanelDemo
{
    /// <summary>
    /// Interaction logic for SplitPanelWindow.xaml
    /// </summary>
    public partial class SplitPanelWindow : Window
    {
        public SplitPanelWindow()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 添加子元素
        /// </summary>
        private void BtnAddChildClick(object sender, RoutedEventArgs e)
        {
            // 生成随机颜色值
            var a = (byte)new Random().Next(0x00, 0xFF);
            Thread.Sleep(20);
            var r = (byte)new Random().Next(0x00, 0xFF);
            Thread.Sleep(20);
            var g = (byte)new Random().Next(0x00, 0xFF);
            Thread.Sleep(20);
            var b = (byte)new Random().Next(0x00, 0xFF);
            var brush = new SolidColorBrush(Color.FromArgb(a, r, g, b));
            Debug.WriteLine(string.Format("a={0},r={1},g={2},b={3}", a, r, g, b));

            // 添加子元素
            TestPanel.Children.Add(new Rectangle { Fill = brush });
        }

        /// <summary>
        /// 移除子元素
        /// </summary>
        private void BtnRemoveChildClick(object sender, RoutedEventArgs e)
        {
            if (TestPanel.Children.Count < 1)
            {
                return;
            }

            var removeChildIndex = new Random().Next(TestPanel.Children.Count);
            TestPanel.Children.RemoveAt(removeChildIndex);
        }
    }
}
