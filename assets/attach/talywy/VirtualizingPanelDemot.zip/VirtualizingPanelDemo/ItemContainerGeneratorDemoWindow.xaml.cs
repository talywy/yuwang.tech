﻿using System.Windows;
using System.Windows.Controls;
using CustomVirtualizingPanel;

namespace VirtualizingPanelDemo
{
    /// <summary>
    /// Interaction logic for ItemContainerGeneratorDemoWindow.xaml
    /// </summary>
    public partial class ItemContainerGeneratorDemoWindow : Window
    {
        private ItemContainerGeneratorDemoPanel _testPanel;

        public ItemContainerGeneratorDemoWindow()
        {
            InitializeComponent();
            Loaded += new RoutedEventHandler(ItemContainerGeneratorDemoWindowLoaded);
        }

        private void ItemContainerGeneratorDemoWindowLoaded(object sender, RoutedEventArgs e)
        {
            if (_testPanel == null)
            {
                TestItemsControl.ApplyTemplate();
                var presenter = (ItemsPresenter)TestItemsControl.Template.FindName("PART_ItemsPresenter", TestItemsControl);
                _testPanel = (ItemContainerGeneratorDemoPanel)TestItemsControl.ItemsPanel.FindName("PART_TestPanel", presenter);
                ShowPositionInfo();
            }
        }

        private void RealizeChild(object sender, SelectionChangedEventArgs e)
        {
            _testPanel.RealizeChild((int)e.AddedItems[0] - 1);
            ShowPositionInfo();
        }

        private void VirtualizeChild(object sender, SelectionChangedEventArgs e)
        {
            _testPanel.VirtualizeChild((int)e.AddedItems[0] - 1);
            ShowPositionInfo();
        }

        private void ShowPositionInfo()
        {
            Log.AppendText(_testPanel.DumpGeneratorContent());
            LogScroller.ScrollToBottom();
        }

    }
}
