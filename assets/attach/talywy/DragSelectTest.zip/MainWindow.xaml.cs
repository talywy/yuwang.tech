﻿using System;
using System.Linq;
using System.Windows;

namespace DragSelectTest
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MainWindow" /> class
        /// <para></para>
        /// </summary>
        public MainWindow()
        {
            this.InitializeComponent();
        }

        private void ListViewDragSelected(object sender, DragSelectedEventArgs e)
        {
            string log = e.SlectedItems.Cast<object>().Aggregate("DragSelected Items:", (current, item) => current + (item + "、"));

            TxtLog.AppendText(log.TrimEnd('、') + Environment.NewLine);
        }
    }
}
