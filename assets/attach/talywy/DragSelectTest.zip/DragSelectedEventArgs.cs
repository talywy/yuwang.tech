﻿using System;
using System.Collections;

namespace DragSelectTest
{
    public class DragSelectedEventArgs : EventArgs
    {
        public DragSelectedEventArgs(IList selectedItems)
        {
            if (selectedItems == null)
            {
                throw new ArgumentNullException("selectedItems");
            }

            SlectedItems = selectedItems;
        }

        /// <summary>
        /// 拖拽选中的条目
        /// </summary>
        public IList SlectedItems
        {
            get;
            private set;
        }
    }
}
