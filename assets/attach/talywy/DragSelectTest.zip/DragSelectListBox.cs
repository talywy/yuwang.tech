﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Shapes;

namespace DragSelectTest
{
    /// <summary>
    /// Follow steps 1a or 1b and then 2 to use this custom control in a XAML file.
    ///
    /// Step 1a) Using this custom control in a XAML file that exists in the current project.
    /// Add this XmlNamespace attribute to the root element of the markup file where it is 
    /// to be used:
    ///
    ///     xmlns:MyNamespace="clr-namespace:DragSelectTest"
    ///
    ///
    /// Step 1b) Using this custom control in a XAML file that exists in a different project.
    /// Add this XmlNamespace attribute to the root element of the markup file where it is 
    /// to be used:
    ///
    ///     xmlns:MyNamespace="clr-namespace:DragSelectTest;assembly=DragSelectTest"
    ///
    /// You will also need to add a project reference from the project where the XAML file lives
    /// to this project and Rebuild to avoid compilation errors:
    ///
    ///     Right click on the target project in the Solution Explorer and
    ///     "Add Reference"->"Projects"->[Browse to and select this project]
    ///
    ///
    /// Step 2)
    /// Go ahead and use your control in the XAML file.
    ///
    ///     <MyNamespace:ExListBox/>
    ///
    /// </summary>
    [TemplatePart(Name = "PART_SelectArea", Type = typeof(Rectangle))]
    [TemplatePart(Name = "PART_DragThumb", Type = typeof(Thumb))]
    public class DragSelectListBox : ListBox
    {
        #region Event

        public event EventHandler<DragSelectedEventArgs> DragSelected;

        #endregion

        #region Field

        private Rectangle _selectArea;
        private Thumb _dragThumb;

        #endregion

        #region DependencyProperty

        public static readonly DependencyProperty IsDragSelectedProperty = DependencyProperty.RegisterAttached(
            "IsDragSelected", typeof(bool), typeof(DragSelectListBox));

        public static bool GetIsDragSelected(DependencyObject element)
        {
            return (bool)element.GetValue(IsDragSelectedProperty);
        }

        public static void SetIsDragSelected(DependencyObject element, bool isDragSelected)
        {
            if (element == null)
            {
                throw new ArgumentNullException("element");
            }

            element.SetValue(IsDragSelectedProperty, isDragSelected);
        }

        #endregion

        #region Construct

        static DragSelectListBox()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(DragSelectListBox), new FrameworkPropertyMetadata(typeof(DragSelectListBox)));
        }

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            _selectArea = (Rectangle)this.Template.FindName("PART_SelectArea", this);
            _dragThumb = (Thumb)this.Template.FindName("PART_DragThumb", this);
            _dragThumb.DragStarted += ThumbDragStarted;
            _dragThumb.DragDelta += ThumbDragDelta;
            _dragThumb.DragCompleted += ThumbDragCompleted;
        }

        #endregion

        #region Private Method

        /// <summary>
        /// 拖拽
        /// </summary>
        private void ThumbDragDelta(object sender, DragDeltaEventArgs e)
        {
            // 绘制选择框
            if (e.HorizontalChange < 0)
            {
                var right = Canvas.GetLeft(_selectArea) + _selectArea.Width;
                Canvas.SetLeft(_selectArea, right + e.HorizontalChange);
            }

            if (e.VerticalChange < 0)
            {
                var bottom = Canvas.GetTop(_selectArea) + _selectArea.Height;
                Canvas.SetTop(_selectArea, bottom + e.VerticalChange);
            }

            _selectArea.Width = Math.Abs(e.HorizontalChange);
            _selectArea.Height = Math.Abs(e.VerticalChange);

            // 计算子元素条目和否和拖拽选择区域相交
            // 选择框区域信息
            var selectAreaLocation = new Point(Canvas.GetLeft(_selectArea), Canvas.GetTop(_selectArea));
            var selectAreaSize = new Size(_selectArea.Width, _selectArea.Height);
            var selectRect = new Rect(selectAreaLocation, selectAreaSize);
            Debug.WriteLine("selectRect:{0}", selectRect);

            foreach (var item in this.Items)
            {
                var container = this.ItemContainerGenerator.ContainerFromItem(item) as ContentControl;
                if (container != null)
                {
                    var transform = container.TransformToAncestor(this);
                    var location = transform.Transform(new Point());

                    // 数据项容器区域信息
                    var containerRect = new Rect(location, new Size(container.ActualWidth, container.ActualHeight));
                    Debug.WriteLine("containerRect:{0}", containerRect);
                    SetIsDragSelected(container, selectRect.IntersectsWith(containerRect));
                }
            }
        }

        /// <summary>
        /// 拖拽开始
        /// </summary>
        private void ThumbDragStarted(object sender, DragStartedEventArgs e)
        {
            Canvas.SetLeft(_selectArea, e.HorizontalOffset);
            Canvas.SetTop(_selectArea, e.VerticalOffset);
        }

        /// <summary>
        /// 拖拽结束
        /// </summary>
        private void ThumbDragCompleted(object sender, DragCompletedEventArgs e)
        {
            _selectArea.Width = 0;
            _selectArea.Height = 0;

            var dragSelectList = new List<object>();
            foreach (var item in this.Items)
            {
                var container = this.ItemContainerGenerator.ContainerFromItem(item) as ContentControl;
                if (container != null)
                {
                    var isDragSelectd = GetIsDragSelected(container);
                    if (isDragSelectd)
                    {
                        dragSelectList.Add(item);
                    }
                    SetIsDragSelected(container, false);
                }
            }

            if (DragSelected != null)
            {
                DragSelected(this, new DragSelectedEventArgs(dragSelectList));
            }
        }

        #endregion
    }
}
